export declare let crcTable: number[];
